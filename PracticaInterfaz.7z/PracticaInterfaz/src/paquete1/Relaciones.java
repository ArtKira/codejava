/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package paquete1;

/**
 *
 * @author AlumnoTI
 */
public interface Relaciones {
    //constantes 
    public final int CERO=0;
    public final int UNO=1;
    
    //CREAR LOS METODOS 
    public boolean esMenorQue(int n1, int n2);
    public boolean esMayorQue(int n1, int n2);
    public boolean esIgualQue(int n1, int n2);
    public boolean esDiferenteQue(int n1, int n2);
    
}
