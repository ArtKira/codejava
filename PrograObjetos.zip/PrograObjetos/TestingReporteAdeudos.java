public class TestingReporteAdeudos {
    
    public static void main(String[] args) {
        
        //Declaro un objeto de la clase Estudiante

        Estudiante Edgar;
        //Construir un objeto de la clase Etudiante
        Edgar = new Estudiante();

        //Forma #1 de asignar valores a las variables de la clase Estudiante
        Edgar.nombre =" Edgar Ramos";
        //Usando un metodo de la Clase estudiante
        Edgar.reportarAdeudo();
    }
   
}
