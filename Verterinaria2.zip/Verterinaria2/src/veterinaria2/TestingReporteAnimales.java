/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package veterinaria2;

/**
 *
 * @author Arturo
 */
public class TestingReporteAnimales {
    public static void main(String[] args) {
        //creamos el objeto
        Animales perro;
        Animales gato;
        Animales iguana;
        perro= new Animales();
        gato=new Animales();
        iguana=new Animales();
        
        //asignamos valores 
        perro.setNombreAnimal("Kira");
        perro.setRaza("Husky");
        perro.setTipoMascota("Perro");
        perro.setEdad(2);
        perro.setNombreDueño("Hector");
        //mandamos a imprimir 
        System.out.println("El nombre del animal es "+ perro.getNombreAnimal());
        System.out.println("La raza es "+ perro.getRaza());
        System.out.println("el tipo de animal es "+ perro.getTipoMascota());
        System.out.println("La edad es "+ perro.getEdad());
        System.out.println("El dueño es "+ perro.getNombreDueño());
        System.out.println("");
        System.out.println("");
        //asignamos valores 
        gato.setNombreAnimal("Manchas");
        gato.setTipoMascota("Gato");
        gato.setEdad(1);
        gato.setNombreDueño("Dulce");
         //mandamos a imprimir 
        System.out.println("El nombre del animal es "+ gato.getNombreAnimal());
        System.out.println("el tipo de animal es "+ gato.getTipoMascota());
        System.out.println("La edad es "+ gato.getEdad());
        System.out.println("El dueño es "+ gato.getNombreDueño());
        System.out.println("");
        System.out.println("");
        //asignamos valores 
        iguana.setNombreAnimal("Thor");
        iguana.setTipoMascota("Iguana");
        iguana.setEdad(3);
        iguana.setNombreDueño("Elsa");
        //mandamos a imprimir 
        System.out.println("El nombre del animal es "+ iguana.getNombreAnimal());
        System.out.println("el tipo de animal es "+ iguana.getTipoMascota());
        System.out.println("La edad es "+ iguana.getEdad());
        System.out.println("El dueño es "+ iguana.getNombreDueño());
    }
}
