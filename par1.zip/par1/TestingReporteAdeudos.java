public class TestingReporteAdeudos {
    
    public static void main(String[] args) {
        
        //Declaro un objeto de la clase Estudiante

        Estudiante Edgar;
        //Construir un objeto de la clase Etudiante
        Edgar = new Estudiante();
        //Usando un metodo de la Clase estudiante
        Edgar.reportarAdeudo();
    }
   
}
